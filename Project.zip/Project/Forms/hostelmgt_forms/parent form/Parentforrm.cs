﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace parent_form
{
	public partial class Parentforrm : parent_form.Form1
	{
		public Parentforrm()
		{
			InitializeComponent();
		}
	}
}
