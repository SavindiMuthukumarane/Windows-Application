﻿namespace parent_form
{
    partial class arrivaldepature
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.select1 = new System.Windows.Forms.Label();
            this.dateandtime = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.studentname = new System.Windows.Forms.TextBox();
            this.submit = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.combox = new System.Windows.Forms.ComboBox();
            this.stid = new System.Windows.Forms.TextBox();
            this.dandtime = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(149, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Id";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(149, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Full Name";
            // 
            // select1
            // 
            this.select1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.select1.Location = new System.Drawing.Point(149, 296);
            this.select1.Name = "select1";
            this.select1.Size = new System.Drawing.Size(150, 25);
            this.select1.TabIndex = 4;
            this.select1.Text = "Select";
            // 
            // dateandtime
            // 
            this.dateandtime.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateandtime.Location = new System.Drawing.Point(149, 383);
            this.dateandtime.Name = "dateandtime";
            this.dateandtime.Size = new System.Drawing.Size(181, 25);
            this.dateandtime.TabIndex = 5;
            this.dateandtime.Text = "Date and Time";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(149, 477);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "Parent Email";
            // 
            // email
            // 
            this.email.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.email.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.Location = new System.Drawing.Point(379, 469);
            this.email.MinimumSize = new System.Drawing.Size(250, 30);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(350, 30);
            this.email.TabIndex = 11;
            // 
            // studentname
            // 
            this.studentname.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.studentname.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentname.Location = new System.Drawing.Point(379, 213);
            this.studentname.MinimumSize = new System.Drawing.Size(250, 30);
            this.studentname.Name = "studentname";
            this.studentname.Size = new System.Drawing.Size(350, 30);
            this.studentname.TabIndex = 12;
            // 
            // submit
            // 
            this.submit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.submit.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit.Location = new System.Drawing.Point(276, 592);
            this.submit.MinimumSize = new System.Drawing.Size(120, 40);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(120, 40);
            this.submit.TabIndex = 14;
            this.submit.Text = "Submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            this.submit.MouseEnter += new System.EventHandler(this.submit_MouseEnter);
            this.submit.MouseLeave += new System.EventHandler(this.submit_MouseLeave);
            // 
            // clear
            // 
            this.clear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.clear.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(431, 592);
            this.clear.MinimumSize = new System.Drawing.Size(120, 40);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(120, 40);
            this.clear.TabIndex = 16;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            this.clear.MouseEnter += new System.EventHandler(this.clear_MouseEnter);
            this.clear.MouseLeave += new System.EventHandler(this.clear_MouseLeave);
            // 
            // combox
            // 
            this.combox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combox.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combox.FormattingEnabled = true;
            this.combox.Items.AddRange(new object[] {
            "Arrive",
            "Departure"});
            this.combox.Location = new System.Drawing.Point(379, 296);
            this.combox.MinimumSize = new System.Drawing.Size(250, 0);
            this.combox.Name = "combox";
            this.combox.Size = new System.Drawing.Size(350, 32);
            this.combox.TabIndex = 14;
            this.combox.SelectedIndexChanged += new System.EventHandler(this.combox_SelectedIndexChanged);
            // 
            // stid
            // 
            this.stid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stid.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stid.Location = new System.Drawing.Point(379, 127);
            this.stid.MinimumSize = new System.Drawing.Size(250, 30);
            this.stid.Name = "stid";
            this.stid.Size = new System.Drawing.Size(350, 30);
            this.stid.TabIndex = 15;
            this.stid.TextChanged += new System.EventHandler(this.stid_TextChanged);
            // 
            // dandtime
            // 
            this.dandtime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dandtime.CustomFormat = "MM/dd/yyyy HH:mm";
            this.dandtime.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dandtime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dandtime.Location = new System.Drawing.Point(379, 383);
            this.dandtime.MinimumSize = new System.Drawing.Size(250, 30);
            this.dandtime.Name = "dandtime";
            this.dandtime.Size = new System.Drawing.Size(350, 30);
            this.dandtime.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(279, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(482, 40);
            this.label3.TabIndex = 17;
            this.label3.Text = "Student Movement Log";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(735, 469);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 33);
            this.label4.TabIndex = 18;
            this.label4.Text = "@gmail.com";
            // 
            // arrivaldepature
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(882, 682);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dandtime);
            this.Controls.Add(this.stid);
            this.Controls.Add(this.combox);
            this.Controls.Add(this.studentname);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateandtime);
            this.Controls.Add(this.select1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "arrivaldepature";
            this.Text = "arrivaldepature";
            this.Load += new System.EventHandler(this.arrivaldepature_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label select1;
        private System.Windows.Forms.Label dateandtime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox studentname;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.ComboBox combox;
        private System.Windows.Forms.TextBox stid;
        private System.Windows.Forms.DateTimePicker dandtime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}