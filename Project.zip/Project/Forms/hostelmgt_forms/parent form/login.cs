﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parent_form
{
    public partial class login: Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void loginn_Click(object sender, EventArgs e)
        {
            string username = uname.Text.Trim();
            string password = pass.Text.Trim();

            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter both fields!", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\savin\\OneDrive - NSBM\\24.1 Degree 1st year\\Third Semester\\C#\\Project\\hostel_management.accdb";
            using (OleDbConnection con = new OleDbConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT COUNT(*) FROM Login WHERE username=? AND password=?";
                    using (OleDbCommand cmd = new OleDbCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("?", username);
                        cmd.Parameters.AddWithValue("?", password);
                        int count = (int)cmd.ExecuteScalar();

                        if (count > 0)
                        {
                            Main home = new Main();
                            home.Show();
                            this.Hide();
                            MessageBox.Show("Login successful!");
                            // TODO: Open Home Page form here
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
               
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void showpass_CheckedChanged(object sender, EventArgs e)
        {
            pass.UseSystemPasswordChar = !showpass.Checked;
        }

        private void pictureBox1_Resize(object sender, EventArgs e)
        {
            pictureBox1.Left = (this.ClientSize.Width - pictureBox1.Width) / 2;
            pictureBox1.Top = 10; // 10 pixels from the top (you can change this)
        }

        private void login_Load(object sender, EventArgs e)
        {
            // Keep it top center when form resizes
            pictureBox1.Left = (this.ClientSize.Width - pictureBox1.Width) / 2;
            // Keep same top margin
            pictureBox1.Top = 10;
            CenterLoginPanel();

        }
        private void CenterLoginPanel()
        {
            panel1.Left = (this.ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (this.ClientSize.Height - panel1.Height) / 2;
        }

        private void login_Resize(object sender, EventArgs e)
        {
            CenterLoginPanel();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
