﻿namespace parent_form
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aboutbutton = new System.Windows.Forms.Button();
            this.studentbutton = new System.Windows.Forms.Button();
            this.parentbutton = new System.Windows.Forms.Button();
            this.movebutton = new System.Windows.Forms.Button();
            this.emergenvybutton = new System.Windows.Forms.Button();
            this.leavebutton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panelmenu = new System.Windows.Forms.Panel();
            this.backbutton = new System.Windows.Forms.Button();
            this.homebutton = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.welc = new System.Windows.Forms.Label();
            this.footer = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelmenu.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // aboutbutton
            // 
            this.aboutbutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutbutton.Location = new System.Drawing.Point(27, 316);
            this.aboutbutton.Name = "aboutbutton";
            this.aboutbutton.Size = new System.Drawing.Size(240, 40);
            this.aboutbutton.TabIndex = 2;
            this.aboutbutton.Text = "About Us";
            this.aboutbutton.UseVisualStyleBackColor = true;
            this.aboutbutton.Click += new System.EventHandler(this.aboutbutton_Click);
            this.aboutbutton.MouseEnter += new System.EventHandler(this.aboutbutton_MouseEnter);
            this.aboutbutton.MouseLeave += new System.EventHandler(this.aboutbutton_MouseLeave);
            // 
            // studentbutton
            // 
            this.studentbutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentbutton.Location = new System.Drawing.Point(27, 408);
            this.studentbutton.Name = "studentbutton";
            this.studentbutton.Size = new System.Drawing.Size(240, 40);
            this.studentbutton.TabIndex = 3;
            this.studentbutton.Text = "Student Registration";
            this.studentbutton.UseVisualStyleBackColor = true;
            this.studentbutton.Click += new System.EventHandler(this.studentbutton_Click);
            this.studentbutton.MouseEnter += new System.EventHandler(this.studentbutton_MouseEnter);
            this.studentbutton.MouseLeave += new System.EventHandler(this.studentbutton_MouseLeave);
            // 
            // parentbutton
            // 
            this.parentbutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.parentbutton.Location = new System.Drawing.Point(27, 362);
            this.parentbutton.Name = "parentbutton";
            this.parentbutton.Size = new System.Drawing.Size(240, 40);
            this.parentbutton.TabIndex = 4;
            this.parentbutton.Text = "Parent Registration";
            this.parentbutton.UseVisualStyleBackColor = true;
            this.parentbutton.Click += new System.EventHandler(this.parentbutton_Click);
            this.parentbutton.MouseEnter += new System.EventHandler(this.parentbutton_MouseEnter);
            this.parentbutton.MouseLeave += new System.EventHandler(this.parentbutton_MouseLeave);
            // 
            // movebutton
            // 
            this.movebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movebutton.Location = new System.Drawing.Point(27, 465);
            this.movebutton.Name = "movebutton";
            this.movebutton.Size = new System.Drawing.Size(240, 40);
            this.movebutton.TabIndex = 5;
            this.movebutton.Text = "Student Movement";
            this.movebutton.UseVisualStyleBackColor = true;
            this.movebutton.Click += new System.EventHandler(this.movebutton_Click);
            this.movebutton.MouseEnter += new System.EventHandler(this.movebutton_MouseEnter);
            this.movebutton.MouseLeave += new System.EventHandler(this.movebutton_MouseLeave);
            // 
            // emergenvybutton
            // 
            this.emergenvybutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emergenvybutton.Location = new System.Drawing.Point(27, 520);
            this.emergenvybutton.Name = "emergenvybutton";
            this.emergenvybutton.Size = new System.Drawing.Size(240, 40);
            this.emergenvybutton.TabIndex = 6;
            this.emergenvybutton.Text = "Emergency Contact";
            this.emergenvybutton.UseVisualStyleBackColor = true;
            this.emergenvybutton.Click += new System.EventHandler(this.emergenvybutton_Click);
            this.emergenvybutton.MouseEnter += new System.EventHandler(this.emergenvybutton_MouseEnter);
            this.emergenvybutton.MouseLeave += new System.EventHandler(this.emergenvybutton_MouseLeave);
            // 
            // leavebutton
            // 
            this.leavebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leavebutton.Location = new System.Drawing.Point(27, 575);
            this.leavebutton.Name = "leavebutton";
            this.leavebutton.Size = new System.Drawing.Size(240, 40);
            this.leavebutton.TabIndex = 7;
            this.leavebutton.Text = "Short Leave";
            this.leavebutton.UseVisualStyleBackColor = true;
            this.leavebutton.Click += new System.EventHandler(this.leavebutton_Click);
            this.leavebutton.MouseEnter += new System.EventHandler(this.leavebutton_MouseEnter);
            this.leavebutton.MouseLeave += new System.EventHandler(this.leavebutton_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::parent_form.Properties.Resources.image_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(239, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(283, 185);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(16, 33);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 37);
            this.button1.TabIndex = 10;
            this.button1.Text = "Menu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelmenu
            // 
            this.panelmenu.Controls.Add(this.backbutton);
            this.panelmenu.Controls.Add(this.homebutton);
            this.panelmenu.Controls.Add(this.button1);
            this.panelmenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelmenu.Location = new System.Drawing.Point(0, 0);
            this.panelmenu.Name = "panelmenu";
            this.panelmenu.Size = new System.Drawing.Size(267, 722);
            this.panelmenu.TabIndex = 11;
            // 
            // backbutton
            // 
            this.backbutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backbutton.Location = new System.Drawing.Point(16, 76);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(87, 37);
            this.backbutton.TabIndex = 15;
            this.backbutton.Text = "Back";
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // homebutton
            // 
            this.homebutton.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homebutton.Location = new System.Drawing.Point(16, 119);
            this.homebutton.Name = "homebutton";
            this.homebutton.Size = new System.Drawing.Size(87, 37);
            this.homebutton.TabIndex = 16;
            this.homebutton.Text = "Home";
            this.homebutton.UseVisualStyleBackColor = true;
            this.homebutton.Click += new System.EventHandler(this.homebutton_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.welc);
            this.panelMain.Controls.Add(this.leavebutton);
            this.panelMain.Controls.Add(this.movebutton);
            this.panelMain.Controls.Add(this.emergenvybutton);
            this.panelMain.Controls.Add(this.aboutbutton);
            this.panelMain.Controls.Add(this.pictureBox1);
            this.panelMain.Controls.Add(this.studentbutton);
            this.panelMain.Controls.Add(this.parentbutton);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(267, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(806, 722);
            this.panelMain.TabIndex = 12;
            this.panelMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMain_Paint);
            // 
            // welc
            // 
            this.welc.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.welc.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welc.ForeColor = System.Drawing.Color.DarkBlue;
            this.welc.Location = new System.Drawing.Point(111, 253);
            this.welc.Name = "welc";
            this.welc.Size = new System.Drawing.Size(570, 23);
            this.welc.TabIndex = 14;
            this.welc.Text = "NSBM Hostel Complex – Pick an option to begin!";
            this.welc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // footer
            // 
            this.footer.BackColor = System.Drawing.Color.Transparent;
            this.footer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.footer.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.footer.Location = new System.Drawing.Point(267, 698);
            this.footer.Name = "footer";
            this.footer.Size = new System.Drawing.Size(806, 24);
            this.footer.TabIndex = 13;
            this.footer.Text = "© NSBM Green University Hostel Complex\r\n";
            this.footer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1073, 722);
            this.Controls.Add(this.footer);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelmenu);
            this.MinimumSize = new System.Drawing.Size(1000, 700);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.Resize += new System.EventHandler(this.Main_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelmenu.ResumeLayout(false);
            this.panelMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button aboutbutton;
        private System.Windows.Forms.Button studentbutton;
        private System.Windows.Forms.Button parentbutton;
        private System.Windows.Forms.Button movebutton;
        private System.Windows.Forms.Button emergenvybutton;
        private System.Windows.Forms.Button leavebutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panelmenu;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label footer;
        private System.Windows.Forms.Label welc;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Button homebutton;
    }
}