﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Policy;

namespace Students_Registration_Form
{
    public partial class RegistrationStudentForm : Form
    {
        public RegistrationStudentForm()
        {
            InitializeComponent();
            
            this.buttonSubmit.MouseEnter += new EventHandler(this.submit_MouseEnter);
            this.buttonSubmit.MouseLeave += new EventHandler(this.submit_MouseLeave);
          
            this.buttonClear.MouseEnter += new EventHandler(this.clear_MouseEnter);
            this.buttonClear.MouseLeave += new EventHandler(this.clear_MouseLeave);
          
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            textBoxFullName.Clear();
            textBoxFirstName.Clear();
            textBoxLastName.Clear();
            textBoxStudentID.Clear();
            dateTimePickerDOB.Value = DateTime.Now;
            radioButtonMale.Checked = false;
            radioButtonFemale.Checked = false;
            textBoxEmail.Clear();
            textBoxContactNo.Clear();
            checkBoxAgreement.Checked = false;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

     
        private void submit_MouseEnter(object sender, EventArgs e)
        {
 
            buttonSubmit.BackColor = Color.FromArgb(102, 204, 0);
        }

     
        private void submit_MouseLeave(object sender, EventArgs e)
        {
            buttonSubmit.BackColor = SystemColors.Control; 
        }
        
        private void clear_MouseEnter(object sender, EventArgs e)
        {
     
            buttonClear.BackColor = Color.FromArgb(192, 192, 192); 
        }

        
        private void clear_MouseLeave(object sender, EventArgs e)
        {
            
            buttonClear.BackColor = SystemColors.Control; 
        }

        private void buttonSubmit_Click_1(object sender, EventArgs e)
        {
            string fullName = textBoxFullName.Text.Trim();
            string firstName = textBoxFirstName.Text.Trim();
            string lastName = textBoxLastName.Text.Trim();
            string studentID = textBoxStudentID.Text.Trim();
            DateTime dateOfBirth = dateTimePickerDOB.Value.Date;
            string gender = radioButtonMale.Checked ? "Male" : (radioButtonFemale.Checked ? "Female" : "");
            string email = textBoxEmail.Text.Trim();
            string contactNo = textBoxContactNo.Text.Trim();
            bool agreedToTerms = checkBoxAgreement.Checked;
            DateTime registrationDate = DateTime.Now;

            // Check required fields (except checkbox)
            if (string.IsNullOrEmpty(fullName) ||
                string.IsNullOrEmpty(firstName) ||
                string.IsNullOrEmpty(lastName) ||
                string.IsNullOrEmpty(studentID) ||
                string.IsNullOrEmpty(gender) ||
                string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(contactNo))
            {
                MessageBox.Show("Please fill all the fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Checkbox validation
            if (!agreedToTerms)
            {
                MessageBox.Show("Please agree to the checkbox to proceed.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // DOB validation
            if (dateOfBirth > DateTime.Today)
            {
                MessageBox.Show("Date of Birth cannot be in the future.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dateTimePickerDOB.Focus();
                return;
            }

            // Invalid characters in email input
            if (Regex.IsMatch(email, @"[^a-zA-Z0-9._]"))
            {
                MessageBox.Show("Invalid email format. Do not use symbols like @, ;, ', etc.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Auto-complete to full email
             email = email + "@gmail.com";

            // Regex validation of full email
            string emailPattern = @"^[a-zA-Z0-9._]+@gmail\.com$";
            if (!Regex.IsMatch(email, emailPattern))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\savin\\OneDrive - NSBM\\24.1 Degree 1st year\\Third Semester\\C#\\Project\\hostel_management.accdb";
            using (OleDbConnection con = new OleDbConnection(connectionString))
            {
                string query = "INSERT INTO students (FullName, FirstName, LastName, StudentID, DateOfBirth, Gender, EmailAddress, ContactNumber, Agreement, RegistrationDate)VALUES (?, ?, ?, ?, ?,?, ?, ?, ?, ?)";

                using (OleDbCommand cmd = new OleDbCommand(query, con))
                {
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = textBoxFullName.Text.Trim();
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = textBoxFirstName.Text.Trim();
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = textBoxLastName.Text.Trim();
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = textBoxStudentID.Text.Trim();
                    cmd.Parameters.Add("?", OleDbType.Date).Value = dateTimePickerDOB.Value.Date; // Explicitly format date
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = radioButtonMale.Checked ? "Male" : (radioButtonFemale.Checked ? "Female" : "");
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = textBoxEmail.Text.Trim();
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = textBoxContactNo.Text.Trim();
                    cmd.Parameters.Add("?", OleDbType.Boolean).Value = checkBoxAgreement.Checked;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        MessageBox.Show("Student Registered Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearForm();
                    }
                    catch (OleDbException ex) 
                    {
                        MessageBox.Show($"Error saving student registration: {ex.Message}\n\nSQL State: {ex.Errors[0].SQLState}\nNative Error: {ex.Errors[0].NativeError}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void labelFullName_Click(object sender, EventArgs e)
        {

        }

        private void labelFormName2_Click(object sender, EventArgs e)
        {

        }

        private void RegistrationStudentForm_Load(object sender, EventArgs e)
        {
            dateTimePickerDOB.Format = DateTimePickerFormat.Custom;
            dateTimePickerDOB.CustomFormat = "dd/MM/yyyy hh:mm tt";
        }

        private void textBoxStudentID_TextChanged(object sender, EventArgs e)
        {
            if (textBoxStudentID.Text.Length > 6)
            {
                MessageBox.Show("Student ID should not be longer than 6 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxStudentID.Text = textBoxStudentID.Text.Substring(0, 6);  // Trim to 6 digits
                textBoxStudentID.SelectionStart = textBoxStudentID.Text.Length;  // Move cursor to the end
            }
        }
    }
}

