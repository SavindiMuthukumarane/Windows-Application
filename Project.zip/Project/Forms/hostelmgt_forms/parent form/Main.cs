﻿using Emergency_Form;
using Microsoft.Win32;
using Short_Leave;
using Students_Registration_Form;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parent_form
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            aboutbutton.Visible = false;
            parentbutton.Visible = false;
            studentbutton.Visible = false;
            emergenvybutton.Visible = false;
            leavebutton.Visible = false;
            movebutton.Visible = false;

            // Keep it top center when form resizes
            pictureBox1.Left = (this.ClientSize.Width - pictureBox1.Width) / 2;
            // Keep same top margin
            pictureBox1.Top = 10;
            CenterLoginPanel();
        }
        private void CenterLoginPanel()
        { // Center the logo
            pictureBox1.Left = (panelMain.Width - pictureBox1.Width) / 2;

            // Set welcome message below the logo
            welc.Left = (panelMain.Width - welc.Width) / 2;
            welc.Top = pictureBox1.Bottom + 10;

            // Buttons layout vertically below welcome text
            int topStart = welc.Bottom + 20;
            int spacing = 10;
            int buttonHeight = aboutbutton.Height;

            Button[] buttons = new Button[]
            {
        aboutbutton, parentbutton, studentbutton,
        emergenvybutton, leavebutton, movebutton
            };

            foreach (Button btn in buttons)
            {
                btn.Left = (panelMain.Width - btn.Width) / 2;
                btn.Top = topStart;
                topStart += buttonHeight + spacing;
            }

        }
        private void LoadFormIntoPanel(Form form)
        {
            backbutton.Visible = false;
            welc.Visible = false;

            panelMain.Controls.Clear();

            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.None;
            form.StartPosition = FormStartPosition.Manual;

            panelMain.Controls.Add(form);
            form.Show();
            form.Update();

            form.Location = new Point(
                (panelMain.Width - form.Width) / 2,
                (panelMain.Height - form.Height) / 2
            );
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
                aboutbutton.Visible = true;
                parentbutton.Visible = true;
                studentbutton.Visible = true;
                emergenvybutton.Visible = true;
                leavebutton.Visible = true;
                movebutton.Visible = true;
            
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            login loginForm = new login();
            loginForm.Show();
            this.Hide();
        }

        private void homebutton_Click(object sender, EventArgs e)
        {
            // Show the menu panel
            panelmenu.Visible = true;

            // Show all main buttons
            aboutbutton.Visible = true;
            parentbutton.Visible = true;
            studentbutton.Visible = true;
            emergenvybutton.Visible = true;
            leavebutton.Visible = true;
            movebutton.Visible = true;

            // Show welcome message and logo
            welc.Visible = true;
            pictureBox1.Visible = true; // Replace with your actual logo control name

            // Optional: Show back button if needed
            backbutton.Visible = true;

            // Clear any loaded forms
            panelMain.Controls.Clear();

            // Re-add welcome and logo to panelMain if they are part of it
            panelMain.Controls.Add(welc);
            panelMain.Controls.Add(pictureBox1); // Again, use your actual logo control

            // Re-add the 6 buttons to panelMain
            panelMain.Controls.Add(aboutbutton);
            panelMain.Controls.Add(parentbutton);
            panelMain.Controls.Add(studentbutton);
            panelMain.Controls.Add(emergenvybutton);
            panelMain.Controls.Add(leavebutton);
            panelMain.Controls.Add(movebutton);

        }

        private void parentbutton_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new guardian());
        }

        private void movebutton_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new arrivaldepature());
        }

        private void aboutbutton_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new about());
        }

        private void studentbutton_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new RegistrationStudentForm());
        }

        private void emergenvybutton_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new EmergencyForm());
        }

        private void leavebutton_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new ShortLeave());
        }

        private void aboutbutton_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.FromArgb(0, 92, 175); // Darker Blue
            btn.ForeColor = Color.White;
        }

        private void aboutbutton_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
        }

        private void parentbutton_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.FromArgb(0, 92, 175); // Darker Blue
            btn.ForeColor = Color.White;
        }

        private void parentbutton_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
        }

        private void studentbutton_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.FromArgb(0, 92, 175); // Darker Blue
            btn.ForeColor = Color.White;
        }

        private void studentbutton_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
        }

        private void movebutton_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.FromArgb(0, 92, 175); // Darker Blue
            btn.ForeColor = Color.White;
        }

        private void movebutton_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
        }

        private void emergenvybutton_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.FromArgb(0, 92, 175); // Darker Blue
            btn.ForeColor = Color.White;
        }

        private void emergenvybutton_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
        }

        private void leavebutton_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.FromArgb(0, 92, 175); // Darker Blue
            btn.ForeColor = Color.White;
        }

        private void leavebutton_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
        }

        private void Main_Resize(object sender, EventArgs e)
        {
            CenterLoginPanel();
            if (panelMain.Controls.Count > 0)
            {
                Form currentForm = panelMain.Controls[0] as Form;
                if (currentForm != null)
                {
                    currentForm.Location = new Point(
                        (panelMain.Width - currentForm.Width) / 2,
                        (panelMain.Height - currentForm.Height) / 2
                    );
                }
            }
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}