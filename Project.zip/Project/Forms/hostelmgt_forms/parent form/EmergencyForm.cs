﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Runtime.ConstrainedExecution;

namespace Emergency_Form
{
    public partial class EmergencyForm : Form
    {

        //db connection string
        private string dbPath = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\savin\\OneDrive - NSBM\\24.1 Degree 1st year\\Third Semester\\C#\\Project\\hostel_management.accdb";

        public EmergencyForm()
        {
            InitializeComponent();

            btn_Submit.MouseLeave += submit_MouseLeave;
            btn_Clear.MouseEnter += clear_MouseEnter;
            btn_Clear.MouseLeave += clear_MouseLeave;
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            // Assuming these are TextBox names
            string StudentName = Student_Name.Text.Trim();
            string StudentID = Student_ID.Text.Trim();
            string ContactName = Contact_Name.Text.Trim();
            string ContactNumber = Contact_Number.Text.Trim();
            string ContactEmail = Contact_Email.Text.Trim();

            // Auto-complete email if needed
            if (!ContactEmail.Contains("@"))
                ContactEmail += "@gmail.com";

            // Email validation using regex
            string emailPattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            if (!Regex.IsMatch(ContactEmail, emailPattern))
            {
                MessageBox.Show("Invalid email format. Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //  Validation
            if (string.IsNullOrWhiteSpace(StudentName) ||
                string.IsNullOrWhiteSpace(StudentID) ||
                string.IsNullOrWhiteSpace(ContactName) ||
                string.IsNullOrWhiteSpace(ContactNumber) ||
                string.IsNullOrWhiteSpace(ContactEmail))
            {
                MessageBox.Show("All fields are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!checkBox1.Checked)
            {
                MessageBox.Show("Please agree to confirm your details.", "Confirmation Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Save to database
            try
            {
                using (OleDbConnection conn = new OleDbConnection(dbPath))
                {
                    conn.Open();

                    // Check for duplicate StudentID
                    string checkQuery = "SELECT COUNT(*) FROM EmergencyContact WHERE StudentID = ?";
                    using (OleDbCommand checkCmd = new OleDbCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("?", StudentID);
                        int count = (int)checkCmd.ExecuteScalar();

                        if (count > 0)
                        {
                            MessageBox.Show("This Student ID already exists. Try with another index number.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }


                    // Use correct table name with square brackets for spaces
                    string query = "INSERT INTO EmergencyContact (StudentName, StudentID, ContactName, ContactNumber, ContactEmail) VALUES (?, ?, ?, ?, ?)";

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", StudentName);
                        cmd.Parameters.AddWithValue("?", StudentID);
                        cmd.Parameters.AddWithValue("?", ContactName);
                        cmd.Parameters.AddWithValue("?", ContactNumber);
                        cmd.Parameters.AddWithValue("?", ContactEmail);

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Emergency contact Details saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show("Are you sure you want to clear all fields?", "Confirm Clear", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                ClearForm();
            }
        }

        private void ClearForm()
        {
            Student_Name.Clear();
            Student_ID.Clear();
            Contact_Name.Clear();
            Contact_Number.Clear();
            Contact_Email.Clear();
            checkBox1.Checked = false;

            // Optional: set focus back to first field
            Student_Name.Focus();
        }

        private void submit_MouseLeave(object sender, EventArgs e)
        {
            btn_Submit.BackColor = SystemColors.Control;
        }

        private void clear_MouseEnter(object sender, EventArgs e)
        {
            btn_Clear.BackColor = Color.FromArgb(192, 192, 192);
        }

        private void clear_MouseLeave(object sender, EventArgs e)
        {
             btn_Clear.BackColor = SystemColors.Control;
        }

        private void submit_MouseEnter(object sender, EventArgs e)
        {
             btn_Submit.BackColor = Color.FromArgb(102, 204, 0);
        }

        private void EmergencyForm_Load(object sender, EventArgs e)
        {

        }

        private void Student_ID_TextChanged(object sender, EventArgs e)
        {
            if (Student_ID.Text.Length > 6)
            {
                MessageBox.Show("Student ID should not be longer than 6 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Student_ID.Text = Student_ID.Text.Substring(0, 6);  // Trim to 6 digits
                Student_ID.SelectionStart = Student_ID.Text.Length;  // Move cursor to the end
            }
        }
    }
}