﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;        
using System.Text.RegularExpressions;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace parent_form
{
    public partial class arrivaldepature : Form
    {
        public arrivaldepature()
        {
            InitializeComponent();
            // Assign hover event handlers
            submit.MouseEnter += submit_MouseEnter;
            submit.MouseLeave += submit_MouseLeave;

            clear.MouseEnter += clear_MouseEnter;
            clear.MouseLeave += clear_MouseLeave;
        }

        private void clear_Click(object sender, EventArgs e)
        {
            stid.Text = " ";
            studentname.Text = " ";
            combox.Text = " ";
            dandtime.ResetText();
            email.Text = " ";
        }

        private void submit_Click(object sender, EventArgs e)
        {
            string studentId = stid.Text.Trim();
            string studentName = studentname.Text.Trim();
            string status = combox.Text.Trim();
            DateTime dateTime = dandtime.Value;
            string parentEmail = email.Text.Trim();

            // Basic validation
            if (studentId == "" || studentName == "" || status == "" || parentEmail == "")
            {
                MessageBox.Show("Please fill in all fields correctly.");
                return;
            }
            //prevent double @gmail.com if user typed it
            if (parentEmail.EndsWith("@gmail.com"))
                parentEmail = parentEmail.Substring(0, parentEmail.Length - 10);
            //Add @gmail.com
            parentEmail += "@gmail.com";
            // Email validation
            //Email Format Validation for Gamil address
            string emailPattern = @"^[a-zA-Z0-9._%+-]+@gmail\.com$";
            if (!Regex.IsMatch(parentEmail, emailPattern))
            {
                MessageBox.Show("Please enter a valid Gmail username(e.g.,jonh.doe).Do not type @gmail.com-it is added automatically.", "Invalid Email",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            // Save to database
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\savin\\OneDrive - NSBM\\24.1 Degree 1st year\\Third Semester\\C#\\Project\\hostel_management.accdb";

            using (OleDbConnection con = new OleDbConnection(connectionString))
            {
                string query = "INSERT INTO arrivaldepature ([Student_Id], [Student_Name], [Status], [Date_Time], [Parent_Email]) VALUES (?, ?, ?, ?, ?)";

                using (OleDbCommand cmd = new OleDbCommand(query, con))
                {
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = studentId;
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = studentName;
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = status;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = dateTime;
                    cmd.Parameters.Add("?", OleDbType.VarChar).Value = parentEmail;

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving record: " + ex.Message);
                        return; // Stop if saving fails
                    }
                }
            }

            // Send Email using default browser (Gmail)
            try
            {
                string subject = $"{status} Notification for {studentName} (ID: {studentId})";
                string body = $"Dear Parent,\n\n" +
                              $"This is to inform you that your child, {studentName} (Student ID: {studentId}), " +
                              $"has {status.ToLower()}ed at the hostel on {dateTime:yyyy-MM-dd HH:mm}.\n\n" +
                              $"Thank you for your cooperation.\n\nBest Regards,\nNSBM Green University Hostel Complex";

                body = Uri.EscapeDataString(body);
                string mailtoLink = $"https://mail.google.com/mail/?view=cm&fs=1&to={parentEmail}&su={Uri.EscapeDataString(subject)}&body={body}";

                Process.Start(new ProcessStartInfo(mailtoLink) { UseShellExecute = true });

                MessageBox.Show("Record saved and email opened successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data saved but email failed: " + ex.Message);
            }

            // Clear form after everything
            stid.Text = "";
            studentname.Text = "";
            combox.Text = "";
            dandtime.ResetText();
            email.Text = "";
        }
 


        private void combox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combox.SelectedItem != null)
            {
                string selectedType = combox.SelectedItem.ToString();

                if (selectedType == "Arrive")
                {
                    select1.Text = "Arrival Time:";
                }
                else if (selectedType == "Departure")
                {
                    select1.Text = "Departure Time:";
                }
                else
                {
                    // Optional: Handle cases where no item is selected or an unexpected value occurs
                    select1.Text = "Arrival/Departure Time:";
                }
            }
        }

        private void stid_TextChanged(object sender, EventArgs e)
        {
            if (stid.Text.Length > 6)
            {
                MessageBox.Show("Student ID should not be longer than 6 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                stid.Text = stid.Text.Substring(0, 6);  // Trim to 6 digits
                stid.SelectionStart = stid.Text.Length;  // Move cursor to the end
            }
        }



        // Email validation function
        private bool IsValidEmail(string email)
        {
            try
            {
                return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.IgnoreCase);
            }
            catch (Exception)
            {
                return false;
            }
        


    }

        private void submit_MouseEnter(object sender, EventArgs e)
        {
            submit.BackColor = Color.FromArgb(102, 204, 0);

        }

        private void submit_MouseLeave(object sender, EventArgs e)
        {
            submit.BackColor = SystemColors.Control;

        }

        private void clear_MouseEnter(object sender, EventArgs e)
        {
            clear.BackColor = Color.FromArgb(192, 192, 192);
        }

        private void clear_MouseLeave(object sender, EventArgs e)
        {
            clear.BackColor = SystemColors.Control;
        }

        private void arrivaldepature_Load(object sender, EventArgs e)
        {

        }
    }
}
