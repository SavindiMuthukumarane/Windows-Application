﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parent_form
{
    public partial class about: Form
    {
        public about()
        {
            InitializeComponent();
        }

        private void about_Load(object sender, EventArgs e)
        {
            // Separate database paths
            string arrivalDB = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\savin\\OneDrive - NSBM\\24.1 Degree 1st year\\Third Semester\\C#\\Project\\hostel_management.accdb";
            string shortLeaveDB = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\savin\\OneDrive - NSBM\\24.1 Degree 1st year\\Third Semester\\C#\\Project\\hostel_management.accdb";

            // Get data from each database
            int todayArrivals = GetCount("SELECT COUNT(*) FROM arrivaldepature WHERE Status='Arrive' AND DateValue(Date_Time) = DateValue(Now())", arrivalDB);
            int todayDepartures = GetCount("SELECT COUNT(*) FROM arrivaldepature WHERE Status='Depature' AND DateValue(Date_Time) = DateValue(Now())", arrivalDB);
            int shortLeaves = GetCount("SELECT COUNT(*) FROM [Short Leave] WHERE DateValue([Short Leave Date]) = DateValue(Now())", shortLeaveDB);

            //  Update labels
            arrival.Text = "Today's Arrivals: " + todayArrivals.ToString();
            depature.Text = "Today's Departures: " + todayDepartures.ToString();
            leave.Text = "Short Leave Requests: " + shortLeaves.ToString();

        }
        private int GetCount(string query, string databasePath)
        {
            int count = 0;

            try
            {
                using (OleDbConnection conn = new OleDbConnection(databasePath))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        object result = cmd.ExecuteScalar();
                        count = result != null ? Convert.ToInt32(result) : 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }

            return count;
        
            }

    }
}
