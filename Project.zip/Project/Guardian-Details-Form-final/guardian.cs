using System;
using System.Data.OleDb;
using System.Drawing;
using System.Runtime.ConstrainedExecution;
using System.Windows.Forms;

namespace GuardianDetailsForm
{
    public partial class GuardianDetailsForm : Form
    {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ASUS\Desktop\Uni\3 sem(1 year)\Guardian-Details-Form-final\HostelDB.accdb.accdb";

        public GuardianDetailsForm()
        {
            InitializeComponent();
            this.BackColor = Color.White;
            SetupButtons();
            SetupEmailField();
        }

        private void SetupButtons()
        {
            // Submit Button - Green hover
            btnSubmit.BackColor = Color.White;
            btnSubmit.ForeColor = Color.Black;
            btnSubmit.FlatStyle = FlatStyle.Flat;
            btnSubmit.FlatAppearance.BorderColor = Color.Gray;
            btnSubmit.FlatAppearance.MouseOverBackColor = Color.FromArgb(76, 175, 80);
            btnSubmit.FlatAppearance.BorderSize = 1;

            // Clear Button - Ash/Gray hover
            btnClear.BackColor = Color.White;
            btnClear.ForeColor = Color.Black;
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.FlatAppearance.BorderColor = Color.Gray;
            btnClear.FlatAppearance.MouseOverBackColor = Color.FromArgb(189, 189, 189);
            btnClear.FlatAppearance.BorderSize = 1;
        }

        private void SetupEmailField()
        {
            // Create a panel to hold both the textbox and the @gmail.com label
            Panel emailPanel = new Panel();
            emailPanel.Size = new Size(txtEmail.Width, txtEmail.Height);
            emailPanel.Location = txtEmail.Location;
            emailPanel.BackColor = Color.White;

            // Adjust the email textbox
            txtEmail.Width = txtEmail.Width - 80;
            txtEmail.Parent = emailPanel;
            txtEmail.Location = new Point(0, 0);
            txtEmail.Anchor = AnchorStyles.Left | AnchorStyles.Top;

            // Create the @gmail.com label
            Label gmailLabel = new Label();
            gmailLabel.Text = "@gmail.com";
            gmailLabel.AutoSize = true;
            gmailLabel.Location = new Point(txtEmail.Width + 5, (txtEmail.Height - gmailLabel.Height) / 2);
            gmailLabel.ForeColor = Color.Gray;
            gmailLabel.Parent = emailPanel;

            // Replace the original textbox with our panel
            this.Controls.Remove(txtEmail);
            this.Controls.Add(emailPanel);
            emailPanel.SendToBack();

            // Handle email validation
            txtEmail.TextChanged += (sender, e) =>
            {
                // You can add validation logic here if needed
            };
        }

        private void GuardianDetailsForm_Load(object sender, EventArgs e)
        {
        }

        
       

        private void ClearAllFields()
        {
            txtStudentID.Clear();
            txtFullName.Clear();
            txtNIC.Clear();
            txtOccupation.Clear();
            txtAddress.Clear();
            txtContact.Clear();
            txtEmail.Clear();
            txtRelationship.SelectedIndex = -1;
            txtRelationship.Text = ""; // Optional: clears any typed text

        }

        private void btnClear_Click(object sender, EventArgs e) => ClearAllFields();

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                try
                {
                    using (OleDbConnection conn = new OleDbConnection(connectionString))
                    {
                        conn.Open();
                        string query = @"INSERT INTO Guardians 
                                        (StudentID, FullName, NIC, Occupation, 
                                         Address, Contact, Email, Relationship) 
                                        VALUES 
                                        (@StudentID, @FullName, @NIC, @Occupation, 
                                         @Address, @Contact, @Email, @Relationship)";

                        using (OleDbCommand cmd = new OleDbCommand(query, conn))
                        {
                            // Combine the username with @gmail.com
                            string fullEmail = string.IsNullOrWhiteSpace(txtEmail.Text)
                                ? string.Empty
                                : txtEmail.Text + "@gmail.com";

                            cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
                            cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                            cmd.Parameters.AddWithValue("@NIC", txtNIC.Text);
                            cmd.Parameters.AddWithValue("@Occupation", txtOccupation.Text);
                            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                            cmd.Parameters.AddWithValue("@Contact", txtContact.Text);
                            cmd.Parameters.AddWithValue("@Email", fullEmail);
                            cmd.Parameters.AddWithValue("@Relationship", txtRelationship.Text);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Guardian details saved successfully!",
                                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearAllFields();
                            }
                            else
                            {
                                MessageBox.Show("No records were saved.",
                                    "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                catch (OleDbException ex)
                {
                    MessageBox.Show($"Database error: {ex.Message}",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtStudentID.Text))
            {
                MessageBox.Show("Please enter Student ID", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtStudentID.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                MessageBox.Show("Please enter Full Name", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFullName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtNIC.Text))
            {
                MessageBox.Show("Please enter NIC number", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNIC.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtContact.Text))
            {
                MessageBox.Show("Please enter Contact Number", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtContact.Focus();
                return false;
            }

            if (txtRelationship.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a parent type (Father, Mother, or Guardian).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtRelationship.Focus();
                return false;
            }
            return true;
        }

        private void txtStudentID_TextChanged(object sender, EventArgs e)
        {
            if (txtStudentID.Text.Length > 6)
            {
                MessageBox.Show("Student ID should not be longer than 6 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtStudentID.Text = txtStudentID.Text.Substring(0, 6);  // Trim to 6 digits
                txtStudentID.SelectionStart = txtStudentID.Text.Length;  // Move cursor to the end
            }
        }

        private void btnSubmit_MouseEnter(object sender, EventArgs e)
        {
            btnSubmit.BackColor = Color.FromArgb(102, 204, 0);

        }

        private void btnSubmit_MouseLeave(object sender, EventArgs e)
        {
            btnSubmit.BackColor = SystemColors.Control;
        }

        private void btnClear_MouseEnter(object sender, EventArgs e)
        {
            btnClear.BackColor = Color.FromArgb(192, 192, 192);
        }

        private void btnClear_MouseLeave(object sender, EventArgs e)
        {
            btnClear.BackColor = SystemColors.Control;
        }
    }
}